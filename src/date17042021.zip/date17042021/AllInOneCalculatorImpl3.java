package date17042021;

public class AllInOneCalculatorImpl3 extends AllInOneCalculatorImpl2 {
	
	public void mult(float x,float y,float z) {
		System.out.println(x*y*z);
	}
	
}
