package date17042021;

public interface Calculator3FloatArgs {

	public void add(float x,float y,float z);
	public void sub(float x,float y,float z);
	public void div(float x,float y,float z);
	public void mult(float x,float y,float z);
	
}
