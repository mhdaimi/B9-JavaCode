package date17042021;

public class ExecutionCalculatorAllInOne {

	public static void main(String[] args) {

		AllInOneCalculatorImpl3 obj = new AllInOneCalculatorImpl3();
		
		obj.add(10.5f, 5.6f, 33.4f);
		
	}

}
