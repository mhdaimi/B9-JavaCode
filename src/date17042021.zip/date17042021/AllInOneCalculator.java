package date17042021;

public interface AllInOneCalculator extends Calculator3IntArgs, Calculator3FloatArgs{

		
}
