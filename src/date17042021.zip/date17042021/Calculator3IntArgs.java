package date17042021;

public interface Calculator3IntArgs {

	public void add(int x,int y,int z);
	public void sub(int x,int y,int z);
	public void div(int x,int y,int z);
	public void mult(int x,int y,int z);
	
	
}
