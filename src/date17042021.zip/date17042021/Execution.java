package date17042021;

public class Execution {

	public static void main(String[] args) {

		CalculatorImplementation calc = new CalculatorImplementation();
		calc.add(10, 20);
		
	}

}
