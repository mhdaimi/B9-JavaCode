package date17042021;

public interface Calculator {
	
	public void add(int x, int y);
	public void sub(int x, int y);
	public void mult(int x, int y);
	public void div(int x, int y);

}
